#!/bin/bash
# =============================================================================
#  my_panel  —  LinuxCNC QtVCP Panel Installer
#  Version 1.0
#
#  Usage:
#    chmod +x install.sh
#    ./install.sh
#
#  What it does:
#    1. Detects the current Linux username automatically
#    2. Creates the config folder ~/linuxcnc/configs/my_panel/
#    3. Copies all panel files into that folder
#    4. Patches my_panel.ini with the correct username/paths
#    5. Makes all M-code scripts executable
#    6. Prints a ready-to-run launch command
#
#  Requirements:
#    - LinuxCNC 2.8 or 2.9 installed
#    - User is in the correct LinuxCNC group (usually 'dialout' or 'linuxcnc')
# =============================================================================

set -e  # Exit immediately on any error

# ── Colours for output ────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
BOLD='\033[1m'
NC='\033[0m'  # No Colour

print_header() { echo -e "\n${BOLD}${BLUE}=== $1 ===${NC}"; }
print_ok()     { echo -e "  ${GREEN}✓${NC}  $1"; }
print_warn()   { echo -e "  ${YELLOW}⚠${NC}  $1"; }
print_err()    { echo -e "  ${RED}✗${NC}  $1"; }
print_info()   { echo -e "      $1"; }

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}║     my_panel  LinuxCNC QtVCP Installer       ║${NC}"
echo -e "${BOLD}╚══════════════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Detect environment ────────────────────────────────────────────────
print_header "Detecting environment"

# Resolve actual username (works even if run with sudo)
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(eval echo "~$REAL_USER")

print_ok "User       : $REAL_USER"
print_ok "Home       : $REAL_HOME"

# Locate installer's own directory (where panel_files/ lives)
INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PANEL_FILES="$INSTALLER_DIR/panel_files"

if [ ! -d "$PANEL_FILES" ]; then
    print_err "panel_files/ directory not found next to install.sh"
    print_info "Expected: $PANEL_FILES"
    exit 1
fi
print_ok "Source     : $PANEL_FILES"

# Check LinuxCNC is installed
if ! command -v linuxcnc &>/dev/null; then
    print_warn "linuxcnc command not found in PATH"
    print_info "Make sure LinuxCNC is installed before running the panel"
fi

# ── Step 2: Define target paths ───────────────────────────────────────────────
print_header "Target paths"

CONFIG_DIR="$REAL_HOME/linuxcnc/configs/my_panel"
MCODE_DIR="$CONFIG_DIR/mcodes"
NC_DIR="$REAL_HOME/linuxcnc/nc_files"

print_info "Config dir : $CONFIG_DIR"
print_info "M-code dir : $MCODE_DIR"
print_info "NC files   : $NC_DIR"

# ── Step 3: Create directories ────────────────────────────────────────────────
print_header "Creating directories"

mkdir -p "$CONFIG_DIR"
print_ok "Created: $CONFIG_DIR"

mkdir -p "$MCODE_DIR"
print_ok "Created: $MCODE_DIR"

mkdir -p "$NC_DIR"
print_ok "Created: $NC_DIR"

# ── Step 4: Copy panel files ──────────────────────────────────────────────────
print_header "Copying panel files"

PANEL_CORE_FILES=(
    "my_panel_handler.py"
    "my_panel.hal"
    "my_panel_postgui.hal"
    "my_panel.ui"
    "tool.tbl"
    "sim.var"
)

# Copy core panel files
for f in "${PANEL_CORE_FILES[@]}"; do
    if [ -f "$PANEL_FILES/$f" ]; then
        cp "$PANEL_FILES/$f" "$CONFIG_DIR/$f"
        print_ok "Copied: $f"
    else
        print_warn "Missing source file: $f"
    fi
done

# Copy pref file (only if not already present — preserve user's saved settings)
if [ ! -f "$CONFIG_DIR/my_panel.pref" ]; then
    cp "$PANEL_FILES/my_panel.pref" "$CONFIG_DIR/my_panel.pref"
    print_ok "Copied: my_panel.pref  (fresh install)"
else
    print_warn "Skipped: my_panel.pref  (already exists — user settings preserved)"
fi

# Copy M-code scripts
for f in "$PANEL_FILES/mcodes/"*; do
    fname=$(basename "$f")
    cp "$f" "$MCODE_DIR/$fname"
    print_ok "Copied mcode: $fname"
done

# ── Step 5: Patch my_panel.ini with correct paths ────────────────────────────
print_header "Patching my_panel.ini"

INI_SRC="$PANEL_FILES/my_panel.ini"
INI_DST="$CONFIG_DIR/my_panel.ini"

# Read original and replace every occurrence of the old username path
# with the current user's actual paths
sed \
    -e "s|/home/[^/]*/linuxcnc/configs/[^/]*/mcodes|$MCODE_DIR|g" \
    -e "s|/home/[^/]*/linuxcnc/nc_files|$NC_DIR|g" \
    -e "s|/home/[^/]*/linuxcnc/configs/[^/]*|$CONFIG_DIR|g" \
    "$INI_SRC" > "$INI_DST"

# Verify the critical lines were patched
if grep -q "$REAL_USER" "$INI_DST" || ! grep -q "meukron" "$INI_DST"; then
    print_ok "Patched USER_M_PATH  → $MCODE_DIR"
    print_ok "Patched PROGRAM_PREFIX → $NC_DIR"
else
    print_warn "Path substitution may be incomplete — verify my_panel.ini manually"
fi

# Show the patched lines
echo ""
print_info "Patched INI lines:"
grep -E "USER_M_PATH|PROGRAM_PREFIX|SUBROUTINE_PATH" "$INI_DST" | while read line; do
    print_info "  $line"
done

# ── Step 6: Set file permissions ──────────────────────────────────────────────
print_header "Setting permissions"

# Make M-code scripts executable (LinuxCNC requires this)
chmod +x "$MCODE_DIR"/M1* 2>/dev/null || true
chmod +x "$MCODE_DIR"/*.py 2>/dev/null || true
print_ok "M-code scripts made executable"

# Ensure all config files are readable
chmod 644 "$CONFIG_DIR"/*.py \
           "$CONFIG_DIR"/*.hal \
           "$CONFIG_DIR"/*.ui \
           "$CONFIG_DIR"/*.ini \
           "$CONFIG_DIR"/*.var \
           "$CONFIG_DIR"/*.tbl \
           "$CONFIG_DIR"/*.pref 2>/dev/null || true
print_ok "Config file permissions set (644)"

# Fix ownership if installer was run with sudo
if [ -n "$SUDO_USER" ]; then
    chown -R "$REAL_USER:$REAL_USER" "$REAL_HOME/linuxcnc"
    print_ok "Ownership set to $REAL_USER"
fi

# ── Step 7: Verify installation ───────────────────────────────────────────────
print_header "Verifying installation"

REQUIRED_FILES=(
    "$CONFIG_DIR/my_panel.ini"
    "$CONFIG_DIR/my_panel.hal"
    "$CONFIG_DIR/my_panel_postgui.hal"
    "$CONFIG_DIR/my_panel_handler.py"
    "$CONFIG_DIR/my_panel.ui"
    "$CONFIG_DIR/my_panel.pref"
    "$CONFIG_DIR/tool.tbl"
    "$CONFIG_DIR/sim.var"
    "$MCODE_DIR/M100"
    "$MCODE_DIR/M101"
    "$MCODE_DIR/mcode_send.py"
)

ALL_OK=true
for f in "${REQUIRED_FILES[@]}"; do
    if [ -f "$f" ]; then
        print_ok "$(basename $f)"
    else
        print_err "MISSING: $f"
        ALL_OK=false
    fi
done

# ── Step 8: Final summary ─────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}╔══════════════════════════════════════════════╗${NC}"
if $ALL_OK; then
    echo -e "${BOLD}║  ${GREEN}Installation complete!${NC}${BOLD}                       ║${NC}"
else
    echo -e "${BOLD}║  ${YELLOW}Installation finished with warnings${NC}${BOLD}          ║${NC}"
fi
echo -e "${BOLD}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BOLD}To launch the panel:${NC}"
echo ""
echo -e "  ${GREEN}linuxcnc $CONFIG_DIR/my_panel.ini${NC}"
echo ""
echo -e "${BOLD}Config installed at:${NC}"
echo -e "  $CONFIG_DIR"
echo ""
