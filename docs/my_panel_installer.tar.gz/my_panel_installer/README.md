# my_panel — LinuxCNC QtVCP Panel Installer

A portable installer for the **my_panel** QtVCP panel for LinuxCNC.

---

## Package Contents

```
my_panel_installer/
├── install.sh              ← Run this to install
├── uninstall.sh            ← Run this to remove
├── README.md               ← This file
└── panel_files/            ← All panel source files (do not edit)
    ├── my_panel.ini
    ├── my_panel.hal
    ├── my_panel_postgui.hal
    ├── my_panel_handler.py
    ├── my_panel.ui
    ├── my_panel.pref
    ├── tool.tbl
    ├── sim.var
    └── mcodes/
        ├── mcode_send.py
        ├── M100
        ├── M101
        ├── M102
        ├── M103
        ├── M104
        ├── M105
        ├── M106
        ├── M107
        └── M108
```

---

## Requirements

- LinuxCNC 2.8 or 2.9 installed
- Python 3.x (included with LinuxCNC)
- A user account with LinuxCNC access

---

## Installation

### Step 1 — Extract the package

```bash
tar -xzf my_panel_installer.tar.gz
cd my_panel_installer
```

### Step 2 — Run the installer

```bash
chmod +x install.sh
./install.sh
```

The installer will:
- Detect your username automatically
- Create `~/linuxcnc/configs/my_panel/`
- Copy all panel files into that folder
- Patch `my_panel.ini` with your correct home directory paths
- Make all M-code scripts executable
- Print the launch command when done

### Step 3 — Launch the panel

```bash
linuxcnc ~/linuxcnc/configs/my_panel/my_panel.ini
```

Or open LinuxCNC and select the config from the launcher.

---

## What Gets Installed

| Destination | Contents |
|---|---|
| `~/linuxcnc/configs/my_panel/` | INI, HAL, UI, handler, pref, tool table, sim.var |
| `~/linuxcnc/configs/my_panel/mcodes/` | M100–M108 scripts + mcode_send.py |
| `~/linuxcnc/nc_files/` | Created if absent (your G-code folder) |

---

## Re-installing / Updating

Running `install.sh` again will overwrite all panel files **except** `my_panel.pref`.  
Your saved camera zoom and other preferences are preserved on reinstall.

To force-reset preferences:

```bash
rm ~/linuxcnc/configs/my_panel/my_panel.pref
./install.sh
```

---

## Uninstalling

```bash
./uninstall.sh
```

This removes `~/linuxcnc/configs/my_panel/` only.  
Your `~/linuxcnc/nc_files/` folder is never touched.

---

## Troubleshooting

**Panel does not start — "cannot find handler"**  
Make sure `my_panel_handler.py` is in the same folder as `my_panel.ini`.

**M-codes do nothing**  
Check that M-code scripts are executable:
```bash
chmod +x ~/linuxcnc/configs/my_panel/mcodes/M1*
```

**Preferences not saving**  
The `my_panel.pref` file must be writable:
```bash
chmod 644 ~/linuxcnc/configs/my_panel/my_panel.pref
```

**Wrong paths in INI after install**  
Open `my_panel.ini` and check these lines match your username:
```ini
USER_M_PATH  = /home/YOUR_USER/linuxcnc/configs/my_panel/mcodes
PROGRAM_PREFIX = /home/YOUR_USER/linuxcnc/nc_files
```
