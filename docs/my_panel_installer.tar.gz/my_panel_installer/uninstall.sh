#!/bin/bash
# =============================================================================
#  my_panel  —  Uninstaller
#  Removes the panel config directory only.
#  Does NOT touch ~/linuxcnc/nc_files (may contain user G-code).
# =============================================================================

REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME=$(eval echo "~$REAL_USER")
CONFIG_DIR="$REAL_HOME/linuxcnc/configs/my_panel"

echo ""
echo "This will remove: $CONFIG_DIR"
read -p "Are you sure? (yes/no): " CONFIRM

if [ "$CONFIRM" = "yes" ]; then
    rm -rf "$CONFIG_DIR"
    echo "✓ Removed: $CONFIG_DIR"
    echo "  nc_files and other LinuxCNC config folders were not touched."
else
    echo "Uninstall cancelled."
fi
echo ""
